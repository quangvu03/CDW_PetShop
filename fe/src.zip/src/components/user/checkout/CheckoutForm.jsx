import React from 'react';

export default function CheckoutForm({
  provinces = [],
  districts = [],
  wards = [],
  addressData = {},
  onAddressChange,
  onSubmit,
}) {
  // Đảm bảo addressData có các giá trị mặc định
  const safeAddressData = {
    fullName: '',
    phoneNumber: '',
    email: '',
    country: '',
    district: '',
    ward: '',
    address: '',
    ...addressData,
  };

  return (
    <div className="checkout-form">
      <h2 style={{ margin: '20px 10px' }}>Thông tin giao hàng</h2>
      {provinces.length === 0 ? (
        <div>Đang tải dữ liệu địa điểm...</div>
      ) : (
        <form className="form d-flex" onSubmit={onSubmit}>
          <div className="row col-lg-12">
            {/* Họ và tên */}
            <div className="col-lg-6 col-md-6 col-12 form-group">
              <label>Họ và tên<span>*</span></label>
              <input
                name="fullName"
                type="text"
                className="form-control"
                value={safeAddressData.fullName}
                onChange={onAddressChange}
                required
              />
            </div>
            {/* Số điện thoại */}
            <div className="col-lg-6 col-md-6 col-12 form-group">
              <label>Số điện thoại<span>*</span></label>
              <input
                name="phoneNumber"
                type="text"
                className="form-control"
                value={safeAddressData.phoneNumber}
                onChange={onAddressChange}
                required
              />
            </div>
            {/* Email */}
            <div className="col-lg-6 col-md-6 col-12 form-group">
              <label>Email<span>*</span></label>
              <input
                name="email"
                type="email"
                className="form-control"
                value={safeAddressData.email}
                onChange={onAddressChange}
                required
              />
            </div>
            {/* Tỉnh/Thành phố */}
            <div className="col-lg-6 col-md-6 col-12 form-group">
              <label>Tỉnh/Thành phố<span>*</span></label>
              <select
                name="country"
                value={safeAddressData.country}
                onChange={onAddressChange}
                className="form-control"
                required
              >
                <option value="">Chọn tỉnh/thành phố</option>
                {provinces.map((p) => (
                  <option key={p.code} value={p.name}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
            {/* Quận/Huyện */}
            <div className="col-lg-6 col-md-6 col-12 form-group">
              <label>Quận/Huyện<span>*</span></label>
              <select
                name="district"
                value={safeAddressData.district}
                onChange={onAddressChange}
                className="form-control"
                required
                disabled={!districts.length}
              >
                <option value="">Chọn quận/huyện</option>
                {districts.map((d) => (
                  <option key={d.code} value={d.name}>
                    {d.name}
                  </option>
                ))}
              </select>
            </div>
            {/* Xã/Phường */}
            <div className="col-lg-6 col-md-6 col-12 form-group">
              <label>Xã/Phường<span>*</span></label>
              <select
                name="ward"
                value={safeAddressData.ward}
                onChange={onAddressChange}
                className="form-control"
                required
                disabled={!wards.length}
              >
                <option value="">Chọn xã/phường</option>
                {wards.map((w) => (
                  <option key={w.code} value={w.name}>
                    {w.name}
                  </option>
                ))}
              </select>
            </div>
            {/* Địa chỉ cụ thể */}
            <div className="col-12 form-group">
              <label>Địa chỉ cụ thể<span>*</span></label>
              <input
                name="address"
                type="text"
                className="form-control"
                value={safeAddressData.address}
                onChange={onAddressChange}
                required
              />
            </div>
            <div className="col-12 form-group">
              <button type="submit" className="btn btn-primary">
                Xác nhận giao hàng
              </button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
}