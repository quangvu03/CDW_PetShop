import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import styles from '../../assets/user/css/OrderDetails.module.css';
import { getOrderDetail } from '../../services/checkoutService'; // Updated import

const OrderDetails = () => {
  const { state } = useLocation();
  const orderId = state?.orderId; // Lấy orderId từ state
  const navigate = useNavigate();

  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchOrder = async () => {
      if (!orderId) {
        setError('Không tìm thấy đơn hàng.');
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const response = await getOrderDetail(orderId);
        setOrder(response.data.result); // Lưu dữ liệu từ API
        setLoading(false);
      } catch (err) {
        console.error('Lỗi khi lấy chi tiết đơn hàng:', err);
        setError('Không thể tải chi tiết đơn hàng.');
        setLoading(false);
      }
    };

    fetchOrder();
  }, [orderId]);

  if (loading) return <p className={styles.loading}>Đang tải chi tiết đơn hàng...</p>;
  if (error) return <p className={styles.error}>{error}</p>;
  if (!order) return <p className={styles.error}>Không tìm thấy đơn hàng.</p>;

  const subtotal = order.petDtoList.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = order.priceShipping || 0;
  const total = subtotal + shipping;

  return (
    <div className={styles.container}>
      <button
        onClick={() => navigate('/orderstatus')}
        className={styles.backButton}
      >
        Quay lại
      </button>

      <div className={styles.header}>
        <h1 className={styles.logo}>PetShop-LÊĐÌNHVĂN</h1>
        <span className={styles.orderId}>Đơn hàng # {order.orderId}</span>
      </div>

      <hr className={styles.divider} />

      <div className={styles.infoGrid}>
        <div className={styles.infoCard}>
          <h2 className={styles.sectionTitle}>Thông tin thanh toán:</h2>
          <p className={styles.infoLabel}>Khách hàng</p>
          <p className={styles.infoValue}>{order.paymentMethod || 'Không xác định'}</p>
        </div>
        <div className={`${styles.infoCard} ${styles.textRight}`}>
          <h2 className={styles.sectionTitle}>Địa chỉ giao hàng:</h2>
          <p className={styles.infoLabel}>Khách hàng</p>
          <p className={styles.infoValue}>{order.shippingAddress || 'Không có địa chỉ'}</p>
        </div>
      </div>

      <div className={styles.infoGrid}>
        <div className={styles.infoCard}>
          <h2 className={styles.sectionTitle}>Phương thức thanh toán:</h2>
          <p className={styles.infoValue}>{order.paymentMethod || 'Không xác định'}</p>
        </div>
        <div className={`${styles.infoCard} ${styles.textRight}`}>
          <h2 className={styles.sectionTitle}>Ngày đặt hàng:</h2>
          <p className={styles.infoValue}>
            {order.orderDate
              ? new Date(order.orderDate).toLocaleDateString('vi-VN')
              : 'Không xác định'}
          </p>
        </div>
      </div>

      <div className={styles.summary}>
        <h2 className={styles.summaryTitle}>Tóm tắt đơn hàng</h2>

        <div className={styles.tableWrapper}>
          <table className={styles.table}>
            <thead>
              <tr className={styles.tableHeader}>
                <th className={styles.tableCell}>Sản phẩm</th>
                <th className={styles.tableCell}>Giá</th>
                <th className={styles.tableCell}>Số lượng</th>
                <th className={styles.tableCellRight}>Tổng</th>
              </tr>
            </thead>
            <tbody>
              {order.petDtoList.map((item, index) => (
                <tr key={index} className={styles.tableRow}>
                  <td className={styles.tableCell}>{item.name}</td>
                  <td className={styles.tableCell}>${item.price.toFixed(2)}</td>
                  <td className={styles.tableCell}>{item.quantity}</td>
                  <td className={styles.tableCellRight}>
                    ${(item.price * item.quantity).toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className={styles.totals}>
          <div className={styles.totalRow}>
            <span>Tạm tính</span>
            <span>${subtotal.toFixed(2)}</span>
          </div>
          <div className={styles.totalRow}>
            <span>Phí vận chuyển</span>
            <span>${shipping.toFixed(2)}</span>
          </div>
          <div className={styles.totalRowFinal}>
            <span>Tổng cộng</span>
            <span>${total.toFixed(2)}</span>
          </div>
        </div>
      </div>

      <div className={styles.actions}>
        <button
          onClick={() => window.print()}
          className={styles.printButton}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className={styles.icon}
            viewBox="0 0 20 20"
            fill="currentColor"
          >
            <path
              fillRule="evenodd"
              d="M5 4v3H4a2 2 0 00-2 2v3a2 2 0 002 2h1v2a2 2 0 002 2h6a2 2 0 002-2v-2h1a2 2 0 002-2V9a2 2 0 00-2-2h-1V4a2 2 0 00-2-2H7a2 2 0 00-2 2zm8 0v3H7V4h6zm-6 8v4h6v-4H7z"
              clipRule="evenodd"
            />
          </svg>
          In
        </button>
        <button className={styles.sendButton}>Gửi</button>
      </div>
    </div>
  );
};

export default OrderDetails;