export default function PaymentSuccess() {
    return (
        <div>
    <h2>Cảm ơn bạn đã đặt hàng!</h2>
    <p>Đơn hàng của bạn đã được xác nhận. Chúng tôi sẽ liên hệ với bạn sớm nhất.</p>
    <a href="">Xem thông tin đơn hàng</a>
        </div>    
    );
  }