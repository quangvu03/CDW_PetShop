import React, { useEffect, useState } from 'react';
import CartSummary from '../../components/user/checkout/CartSummary';
import PaymentMethod from '../../components/user/checkout/PaymentMethod';
import { getShippingMethods } from '../../services/shippingService';
import { saveOrder } from '../../services/checkoutService';
import { toast } from 'react-toastify';
import Swal from 'sweetalert2'; // Import SweetAlert2
import '../../assets/user/css/User.css';

export default function Checkout() {
  const [checkoutItems, setCheckoutItems] = useState([]);
  const [shippingMethods, setShippingMethods] = useState([]);
  const [selectedShipping, setSelectedShipping] = useState(null);
  const [total, setTotal] = useState(0);
  const [shippingFee, setShippingFee] = useState(0);
  const [provinces, setProvinces] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [wards, setWards] = useState([]);
  const [paymentMethod, setPaymentMethod] = useState('COD');
  const [isLoading, setIsLoading] = useState(false);
  const [addressData, setAddressData] = useState({
    fullName: localStorage.getItem('full_name') || '',
    phoneNumber: '',
    email: '',
    country: '',
    district: '',
    ward: '',
    address: '',
  });

  // Lấy dữ liệu giỏ hàng và phương thức giao hàng
  useEffect(() => {
    const items = JSON.parse(localStorage.getItem('checkout_items')) || [];
    setCheckoutItems(items);

    const fetchShipping = async () => {
      try {
        const res = await getShippingMethods();
        setShippingMethods(res.data);
      } catch (err) {
        console.error('Lỗi khi lấy phương thức giao hàng', err);
      }
    };
    fetchShipping();
  }, []);

  // Lấy dữ liệu tỉnh/thành phố từ API
  useEffect(() => {
    fetch('https://provinces.open-api.vn/api/?depth=3')
      .then(res => res.json())
      .then(data => setProvinces(data))
      .catch(err => console.error('Lỗi khi lấy dữ liệu địa điểm', err));
  }, []);

  // Cập nhật danh sách quận/huyện khi chọn tỉnh/thành phố
  useEffect(() => {
    const selectedProvince = provinces.find(p => p.name === addressData.country);
    setDistricts(selectedProvince ? selectedProvince.districts : []);
    setAddressData(prev => ({ ...prev, district: '', ward: '' }));
  }, [addressData.country, provinces]);

  // Cập nhật danh sách xã/phường khi chọn quận/huyện
  useEffect(() => {
    const selectedDistrict = districts.find(d => d.name === addressData.district);
    setWards(selectedDistrict ? selectedDistrict.wards : []);
    setAddressData(prev => ({ ...prev, ward: '' }));
  }, [addressData.district, districts]);

  // Tính tổng tiền
  useEffect(() => {
    const subtotal = checkoutItems.reduce(
      (sum, item) => sum + (item.pet?.price || item.product?.price || 0) * (item.quantity || 1),
      0
    );
    setTotal(subtotal + shippingFee);
  }, [checkoutItems, shippingFee]);

  // Xử lý thay đổi phương thức giao hàng
  const handleShippingChange = (method) => {
    setSelectedShipping(method);
    setShippingFee(method.price || 0);
  };

  // Xử lý thay đổi phương thức thanh toán
  const handlePaymentChange = (method) => {
    setPaymentMethod(method);
  };

  // Xử lý thay đổi địa chỉ
  const handleAddressChange = (e) => {
    const { name, value } = e.target;
    setAddressData(prev => ({ ...prev, [name]: value }));
  };

  // Xử lý submit form
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    // Lấy thông tin từ localStorage
    const userId = localStorage.getItem('userId');
    const token = localStorage.getItem('token');
    const checkoutItems = JSON.parse(localStorage.getItem('checkout_items')) || [];

    // Kiểm tra dữ liệu bắt buộc
    if (!userId) {
      toast.error('Vui lòng đăng nhập để tiếp tục');
      setIsLoading(false);
      return;
    }
    if (!selectedShipping) {
      toast.error('Vui lòng chọn phương thức giao hàng.');
      setIsLoading(false);
      return;
    }
    if (checkoutItems.length === 0) {
      toast.error('Giỏ hàng trống. Vui lòng thêm sản phẩm.');
      setIsLoading(false);
      return;
    }
    if (
      !addressData.fullName ||
      !addressData.phoneNumber ||
      !addressData.email ||
      !addressData.country ||
      !addressData.district ||
      !addressData.ward ||
      !addressData.address
    ) {
      toast.error('Vui lòng điền đầy đủ thông tin giao hàng.');
      setIsLoading(false);
      return;
    }

    // Tạo địa chỉ giao hàng
    const shippingAddress = `${addressData.address}, ${addressData.ward}, ${addressData.district}, ${addressData.country}`;

    // Tạo payload cho API đơn hàng
    const payload = {
      userId: parseInt(userId),
      totalPrice: total,
      paymentMethod: paymentMethod,
      paymentStatus: 'unpaid',
      shippingAddress: shippingAddress,
      shippingMethodId: selectedShipping.id,
      orderRequestList: checkoutItems
        .map(item => ({
          petId: item.pet?.id || null,
          productId: item.product?.id || null,
          quantity: item.quantity,
          price: item.pet?.price || item.product?.price || 0,
        }))
        .filter(item => item.petId || item.productId),
    };

    // Sử dụng SweetAlert2 để hiển thị hộp thoại xác nhận
    const confirmSend = await Swal.fire({
      title: 'Xác nhận đặt hàng',
      html: `
        <p><strong>Tổng tiền:</strong> ${total} VND</p>
        <p><strong>Phương thức thanh toán:</strong> ${paymentMethod}</p>
        <p><strong>Địa chỉ giao hàng:</strong> ${shippingAddress}</p>
        <p>Vui lòng kiểm tra thông tin đơn hàng. Bạn có muốn đặt hàng ?</p>
      `,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Đồng ý',
      cancelButtonText: 'Hủy',
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
    });

    if (!confirmSend.isConfirmed) {
      setIsLoading(false);
      return;
    }

try {
  const orderResponse = await saveOrder(payload);
  console.log('Phản hồi từ server:', orderResponse.data);

  if (orderResponse.data.success) {
    localStorage.removeItem('checkout_items');

    await Swal.fire({
      title: 'Thành công!',
      text: orderResponse.data.message || 'Đặt hàng thành công!',
      icon: 'success',
      confirmButtonText: 'OK',
    });

    window.location.href = '/order-confirmation';
  } else {
    // Server trả về nhưng `success: false`
    toast.error(orderResponse.data.message || 'Đặt hàng không thành công. Vui lòng thử lại.');
  }
} catch (error) {
  console.error('Lỗi khi xử lý đơn hàng:', error);
  const errorMessage = error.response?.data?.message || 'Đã có lỗi xảy ra khi đặt hàng. Vui lòng thử lại.';
  toast.error(errorMessage);
} finally {
  setIsLoading(false);
}

  };

  return (
    <section className="shop checkout section">
      <div className="container">
        <div className="row">
          <div className="col-lg-8 col-12">
            <div className="checkout-form">
              <h2 style={{ margin: '20px 10px' }}>Thông tin giao hàng</h2>
              {provinces.length === 0 ? (
                <div>Đang tải dữ liệu địa điểm...</div>
              ) : (
                <form className="form d-flex">
                  <div className="row col-lg-12">
                    {/* Họ và tên */}
                    <div className="col-lg-6 col-md-6 col-12 form-group">
                      <label>
                        Họ và tên<span>*</span>
                      </label>
                      <input
                        name="fullName"
                        type="text"
                        className="form-control"
                        value={addressData.fullName}
                        onChange={handleAddressChange}
                        required
                      />
                    </div>
                    {/* Số điện thoại */}
                    <div className="col-lg-6 col-md-6 col-12 form-group">
                      <label>
                        Số điện thoại<span>*</span>
                      </label>
                      <input
                        name="phoneNumber"
                        type="text"
                        className="form-control"
                        value={addressData.phoneNumber}
                        onChange={handleAddressChange}
                        required
                      />
                    </div>
                    {/* Email */}
                    <div className="col-lg-6 col-md-6 col-12 form-group">
                      <label>
                        Email<span>*</span>
                      </label>
                      <input
                        name="email"
                        type="email"
                        className="form-control"
                        value={addressData.email}
                        onChange={handleAddressChange}
                        required
                      />
                    </div>
                    {/* Tỉnh/Thành phố */}
                    <div className="col-lg-6 col-md-6 col-12 form-group">
                      <label>
                        Tỉnh/Thành phố<span>*</span>
                      </label>
                      <select
                        name="country"
                        value={addressData.country}
                        onChange={handleAddressChange}
                        className="form-control"
                        required
                      >
                        <option value="">Chọn tỉnh/thành phố</option>
                        {provinces.map(p => (
                          <option key={p.code} value={p.name}>
                            {p.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    {/* Quận/Huyện */}
                    <div className="col-lg-6 col-md-6 col-12 form-group">
                      <label>
                        Quận/Huyện<span>*</span>
                      </label>
                      <select
                        name="district"
                        value={addressData.district}
                        onChange={handleAddressChange}
                        className="form-control"
                        required
                      >
                        <option value="">Chọn quận/huyện</option>
                        {districts.map(d => (
                          <option key={d.code} value={d.name}>
                            {d.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    {/* Xã/Phường */}
                    <div className="col-lg-6 col-md-6 col-12 form-group">
                      <label>
                        Xã/Phường<span>*</span>
                      </label>
                      <select
                        name="ward"
                        value={addressData.ward}
                        onChange={handleAddressChange}
                        className="form-control"
                        required
                      >
                        <option value="">Chọn xã/phường</option>
                        {wards.map(w => (
                          <option key={w.code} value={w.name}>
                            {w.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    {/* Địa chỉ cụ thể */}
                    <div className="col-12 form-group">
                      <label>
                        Địa chỉ cụ thể<span>*</span>
                      </label>
                      <input
                        name="address"
                        type="text"
                        className="form-control"
                        value={addressData.address}
                        onChange={handleAddressChange}
                        required
                      />
                    </div>
                  </div>
                </form>
              )}
            </div>
          </div>
          <div className="col-lg-4 col-12">
            <CartSummary
              items={checkoutItems}
              shippingMethods={shippingMethods}
              selectedShipping={selectedShipping}
              onShippingChange={handleShippingChange}
              total={total}
              setTotal={setTotal}
              shippingFee={shippingFee}
            />
            <PaymentMethod onPaymentChange={handlePaymentChange} />
            <div className="checkout-actions">
              <button
                type="submit"
                className="btn btn-primary"
                onClick={handleSubmit}
                disabled={isLoading}
              >
                {isLoading ? 'Đang xử lý...' : 'Đặt hàng'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}