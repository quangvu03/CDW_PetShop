import React, { useState, useEffect } from 'react';
import DataTable from 'react-data-table-component';
import { Search, X, Eye } from 'lucide-react';
import styles from '../../assets/user/css/orderstatus.module.css';
import { getOrdersByUser } from '../../services/checkoutService';
import { Link } from 'react-router-dom';

const OrderStatus = () => {
  const [filterText, setFilterText] = useState('');
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const userId = localStorage.getItem('userId');

  useEffect(() => {
    const fetchOrders = async () => {
      if (!userId) {
        setError('Vui lòng đăng nhập để xem đơn hàng.');
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const response = await getOrdersByUser(userId);
        setOrders(response.data);
        setLoading(false);
      } catch (err) {
        console.error('Lỗi khi lấy đơn hàng:', err);
        setError('Không thể tải danh sách đơn hàng.');
        setLoading(false);
      }
    };

    fetchOrders();
  }, [userId]);

  const stats = [
    {
      title: 'Tổng đơn hàng',
      value: `$${orders
        .reduce((sum, order) => sum + order.totalPrice, 0)
        .toLocaleString()}`,
      percentage: 0,
    },
    {
      title: 'Đơn hàng thành công',
      value: `$${orders
        .filter((order) => order.status === 'completed')
        .reduce((sum, order) => sum + order.totalPrice, 0)
        .toLocaleString()}`,
      percentage: 0,
    },
    {
      title: 'Đơn hàng đang chờ',
      value: `$${orders
        .filter((order) => order.status === 'pending')
        .reduce((sum, order) => sum + order.totalPrice, 0)
        .toLocaleString()}`,
      percentage: 0,
    },
    {
      title: 'Số lượng đơn hàng',
      value: orders.length.toString(),
      percentage: 0,
    },
  ];

  const getPaymentIcon = (paymentMethod) => {
    switch (paymentMethod.toLowerCase()) {
      case 'cod':
        return <div className={`${styles.card} ${styles.cod}`}>COD</div>;
      default:
        return <div className={`${styles.card} ${styles.unknown}`}>{paymentMethod}</div>;
    }
  };

  const getStatusBadge = (status) => {
    switch (status.toLowerCase()) {
      case 'pending':
        return <span className={`${styles.badge} ${styles.pending}`}>Đang chờ</span>;
      case 'completed':
        return <span className={`${styles.badge} ${styles.paid}`}>Hoàn thành</span>;
      case 'cancelled':
        return <span className={`${styles.badge} ${styles.refund}`}>Đã hủy</span>;
      default:
        return <span className={`${styles.badge} ${styles.unknown}`}>{status}</span>;
    }
  };

  const columns = [
    {
      name: 'Mã đơn hàng',
      selector: (row) => row.id,
      sortable: true,
      cell: (row) => `#${row.id}`,
    },
    {
      name: 'Số tiền',
      selector: (row) => row.totalPrice,
      sortable: true,
      cell: (row) => `$${row.totalPrice.toLocaleString()}`,
    },
    {
      name: 'Ngày đặt',
      selector: (row) => row.orderDate,
      sortable: true,
      cell: (row) => new Date(row.orderDate).toLocaleDateString('vi-VN'),
    },
    {
      name: 'Thanh toán',
      selector: (row) => row.paymentMethod,
      cell: (row) => getPaymentIcon(row.paymentMethod),
    },
    {
      name: 'Địa chỉ giao hàng',
      selector: (row) => row.shippingAddress,
      sortable: true,
      wrap: true,
    },
    {
      name: 'Trạng thái',
      selector: (row) => row.status,
      cell: (row) => getStatusBadge(row.status),
    },
    {
      name: 'Hành động',
      cell: (row) => (
        <div>
          <Link
            to="/orderdetail"
            state={{ orderId: row.id }} // Truyền id qua state
            title="Xem chi tiết"
          >
            <button className={`${styles['action-btn']} ${styles.edit}`}>
              <Eye size={16} />
            </button>
          </Link>
          <button
            className={`${styles['action-btn']} ${styles.delete}`}
            title="Hủy đơn hàng"
            onClick={() => console.log(`Hủy đơn hàng ${row.id}`)}
          >
            <X size={16} />
          </button>
        </div>
      ),
      ignoreRowClick: true,
      allowOverflow: true,
      button: true,
    },
  ];

  const filteredOrders = orders.filter((order) =>
    Object.values(order).some(
      (val) => val && val.toString().toLowerCase().includes(filterText.toLowerCase())
    )
  );

  const customStyles = {
    headCells: {
      style: {
        fontWeight: 'bold',
        backgroundColor: '#f9f9f9',
      },
    },
    cells: {
      style: {
        padding: '10px',
      },
    },
  };

  return (
    <div className={styles.container}>
      <div className={styles['stats-container']}>
        {stats.map((stat, index) => (
          <div key={index} className={styles['stat-card']}>
            <div className={styles['stat-text']}>
              <p>{stat.title}</p>
              <p>{stat.value}</p>
              <p
                className={stat.percentage >= 0 ? styles['text-green'] : styles['text-red']}
              >
                {stat.percentage >= 0 ? '▲' : '▼'} {Math.abs(stat.percentage)}%
              </p>
            </div>
          </div>
        ))}
      </div>

      <div className={styles['search-wrapper']}>
        <input
          type="text"
          placeholder="Tìm kiếm"
          value={filterText}
          onChange={(e) => setFilterText(e.target.value)}
          className={styles['search-input']}
        />
        <Search size={18} className={styles['search-icon']} />
      </div>

      {loading ? (
        <p>Đang tải đơn hàng...</p>
      ) : error ? (
        <p>{error}</p>
      ) : (
        <DataTable
          title="Lịch sử đơn hàng"
          columns={columns}
          data={filteredOrders}
          pagination
          paginationPerPage={10}
          customStyles={customStyles}
          highlightOnHover
          pointerOnHover
          noDataComponent="Không tìm thấy đơn hàng."
        />
      )}
    </div>
  );
};

export default OrderStatus;